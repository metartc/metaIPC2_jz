﻿//
// Copyright (c) 2019-2024 yanggaofeng
//

#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include "YangMetaipc.h"


#define Yang_Topic_Server "metaIpc/server"


int g_waitState=0;
pthread_mutex_t g_lock ;
pthread_cond_t	g_cond ;

YangMetaIpc* g_yang_ipc=NULL;

static int32_t b_exit = 0;
static void ctrl_c_handler(int s){
	printf("\ncaught signal %d, exit.\n",s);
	b_exit = 1;
	if(g_yang_ipc&&g_yang_ipc->stop)
		g_yang_ipc->stop(g_yang_ipc->session);
	pthread_mutex_lock(&g_lock);
	pthread_cond_signal(&g_cond);
	pthread_mutex_unlock(&g_lock);
}


static int32_t b_reload = 0;
static void reload_handler(int s){
	printf("\ncaught signal %d, reload.\n",s);
	b_reload = 1;
}
void initSignal(struct sigaction* sigIntHandler,struct sigaction* sigHupHandler){
	//ctrl + c to exit
	sigIntHandler->sa_handler = ctrl_c_handler;
	sigemptyset(&sigIntHandler->sa_mask);
	sigIntHandler->sa_flags = 0;
	sigaction(SIGINT, sigIntHandler, 0);

	//hup to reload
	sigHupHandler->sa_handler = reload_handler;
	sigemptyset(&sigHupHandler->sa_mask);
	sigHupHandler->sa_flags = 0;
	sigaction(SIGHUP, sigHupHandler, 0);
}

static void yang_getVideoData(void* session,uint8_t* data,uint32_t nb_data){
	printf("v%u,",nb_data);
}
static int32_t yang_getAudioCaptureData(void* session,uint8_t* data,uint32_t nb_data){
	printf("a%u,",nb_data);
	return 0;
}
int main(int argc, char *argv[])
{
	struct sigaction    sigIntHandler;
	struct sigaction    sigHupHandler;
	
	g_yang_ipc=(YangMetaIpc*)calloc(sizeof(YangMetaIpc),1);
	YangCameraCallback callback;
	YangCAudioCaptureCallback audioCaptureCallback;
	pthread_mutex_init(&g_lock,NULL);
	pthread_cond_init(&g_cond,NULL);

	initSignal(&sigIntHandler,&sigHupHandler);

	callback.session=g_yang_ipc;
	callback.onVideoData=yang_getVideoData;

	audioCaptureCallback.session=g_yang_ipc;
	audioCaptureCallback.onAudioData=yang_getAudioCaptureData;
	if(yang_create_metaIpc(g_yang_ipc,NULL,NULL)){
	//if(yang_create_metaIpc(g_yang_ipc,&callback,&audioCaptureCallback)){
		printf("\ncreate ipc fail!");
		goto cleanup;

	}

	if(g_yang_ipc->start(g_yang_ipc->session,Yang_Topic_Server)){
		printf("\nstart ipc fail!");
		goto cleanup;

	}
	while(!b_exit)
	{
		g_waitState=1;
		pthread_cond_wait(&g_cond, &g_lock);
		g_waitState=0;
		if (b_reload) {
			//reload
			b_reload = 0;

		}
	}

	if(g_yang_ipc->stop)
		g_yang_ipc->stop(g_yang_ipc->session);

	cleanup:
	if(g_yang_ipc){
		yang_destroy_metaIpc(g_yang_ipc);
		free(g_yang_ipc);
	}

	pthread_cond_destroy(&g_cond);
	pthread_mutex_destroy(&g_lock);
	return 1;
	
}
