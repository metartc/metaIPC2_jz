//
// Copyright (c) 2019-2025 yanggaofeng
//

#ifndef SRC_YangMetaipcHd_H_
#define SRC_YangMetaipcHd_H_

#include <stdint.h>
#include <stdio.h>

typedef struct{
	void* session;
	void (*onVideoData)(void* session,uint8_t* data,uint32_t nb_data);
}YangCameraCallback;

typedef struct{
	void* session;
	int32_t (*onAudioData)(void* session,uint8_t* data,uint32_t nb);
}YangCAudioCaptureCallback;


typedef struct{
	void* session;
	int32_t (*onAudioData)(void* session,uint8_t* data,uint32_t nb);
}YangCAudioPlayCallback;

typedef struct{
	void* session;
	int32_t (*stop)(void* session);
	int32_t (*start)(void* session,char* serverTopic);
	int32_t (*getScale)(void* session,uint32_t* width,uint32_t* height,uint32_t* fps);
}YangMetaIpc;

int32_t yang_create_metaIpc(YangMetaIpc* ipc,YangCameraCallback* callback,YangCAudioCaptureCallback* audioCaptureCallback);
void yang_destroy_metaIpc(YangMetaIpc* ipc);

#endif /* SRC_YANGUTIL_SYS_YANGLIB_H_ */
